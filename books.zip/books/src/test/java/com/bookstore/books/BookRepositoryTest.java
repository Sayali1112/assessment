package com.bookstore.books;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import static org.junit.jupiter.api.Assertions.assertEquals;
import java.util.ArrayList;
import java.util.List;
import javax.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.bookstore.books.dao.BookRepository;
import com.bookstore.books.entity.Book;

@ExtendWith(SpringExtension.class)
@Transactional
@SpringBootTest(classes =BooksApplication.class)
class BookRepositoryTest {
	@Autowired
	   private BookRepository bookRepository;
	   @Test
	   public void testFindById() {
	      Book book = getBook();	     
	      bookRepository.save(book);
	      Book result = bookRepository.findById(book.getId()).get();
	      assertEquals(book.getId(), result.getId());	     
	   }
	   @Test
	   public void testFindAll() {
	      Book book = getBook();
	      bookRepository.save(book);
	      List<Book> result = new ArrayList<>();
	      bookRepository.findAll().forEach(e -> result.add(e));
	      assertEquals(result.size(),6);	     
	   }
	   @Test
	   public void testSave() {
	      Book book = getBook();
	      Book book_save= bookRepository.save(book);
	      Book found  = bookRepository.findById(book_save.getId()).get();
	      assertEquals(book.getId(), found.getId());	     
	   }
	   @Test
	   public void testDeleteById() {
	      Book book = getBook();
	      bookRepository.save(book);
	      bookRepository.deleteById(book.getId());
	      List<Book> result = new ArrayList<>();
	      bookRepository.findAll().forEach(e -> result.add(e));
	      assertEquals(result.size(), 5);
	   }
	   
	   private Book getBook() {
		  Book book = new Book();
		  java.util.Date date=new java.util.Date();
		  java.sql.Date sqlDate=new java.sql.Date(date.getTime());
		  book.setId(10);
	      book.setTitle("testTitle1");
	      book.setAuthor("testAuthor");
	      book.setGenre("testGenre");
	      book.setISBN("100030");
	      book.setPublishedDate(sqlDate);
	      return book;
	   }	   
}
