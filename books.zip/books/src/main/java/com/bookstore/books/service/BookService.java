package com.bookstore.books.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.bookstore.books.dao.BookRepository;
import com.bookstore.books.entity.Book;

import java.util.List;
 
@Component
public class BookService {

	@Autowired
	private BookRepository bookRepository;
	
    public List<Book> getAllBooks() {
        return bookRepository.findAll();
    }
 
    public Book getBookById(Long id) {
        return bookRepository.findById(id).orElse(null);
    }
 
    public Book saveOrUpdate(Book book) {
        return bookRepository.save(book);
    }
 
    public void deleteBook(Long id) {
        bookRepository.deleteById(id);
    }
}