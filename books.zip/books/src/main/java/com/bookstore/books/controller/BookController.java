package com.bookstore.books.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import com.bookstore.books.entity.Book;
import com.bookstore.books.service.BookService;
import java.util.List;
 
@RestController
@RequestMapping("/books")
public class BookController {
 
	@Autowired
	private BookService bookService;
	
    @GetMapping
    public List<Book> getAllBooks() {
        return bookService.getAllBooks();
    }
 
    @GetMapping("/{id}")
    public String getBookById(@PathVariable Long id) {
    	String book_obj = "";
    	Book book = bookService.getBookById(id);
    	if(book!=null)
    	{
	    	book_obj=book_obj.concat("title:"+book.getTitle());
	    	book_obj=book_obj.concat("\nAuthor:"+book.getAuthor());
	    	book_obj=book_obj.concat("\nISBN:"+book.getISBN());
	    	book_obj=book_obj.concat("\nPublication Date:"+book.getPublishedDate());
	    	book_obj=book_obj.concat("\nGenre:"+book.getGenre());
    	}
        return book_obj;
    }
 
    @PostMapping
    public Book saveBook(@RequestBody Book book) {
       return bookService.saveOrUpdate(book);
    }
 
    @DeleteMapping("/{id}")
    public void deleteBook(@PathVariable Long id) {
        bookService.deleteBook(id);
    }
}